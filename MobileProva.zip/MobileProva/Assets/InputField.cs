using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class script : MonoBehaviour
{
    public InputField input;
    void Start()
    {
        input.text = "some text for input";
        {


        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
